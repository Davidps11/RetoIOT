class Presion:
    def __init__(self,id,presion,fecha):
        self.id=id
        self.presion=presion
        self.fecha=fecha
