class Temperatura:
    def __init__(self,id,temperatura,fecha):
        self.id=id
        self.temperatura=temperatura
        self.fecha=fecha