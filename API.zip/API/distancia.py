class Distancia:
    def __init__(self,id,distancia,fecha):
        self.id=id
        self.distancia=distancia
        self.fecha=fecha