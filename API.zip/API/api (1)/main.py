from fastapi import FastAPI
import mysql.connector
from temperatura import Temperatura
from distancia import Distancia
from presion import Presion
from fastapi.middleware.cors import CORSMiddleware


origins = [
    "http://localhost:3000",
]

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
mydb = mysql.connector.connect(
  host="34.135.173.85",
  user="root",
  password="Furby",
  database="carrito"
)

@app.get("/temperaturas")
async def root():
    temperaturas=[]
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM temperatura")
    temperaturas_db = mycursor.fetchall()
    mydb.commit()
    for temperatura in temperaturas_db:
        t=Temperatura(temperatura[0],temperatura[1],temperatura[2])
        temperaturas.append(t)
    return temperaturas

@app.get("/presion")
async def root():
    presiones=[]
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM presion")
    presiones_db = mycursor.fetchall()
    mydb.commit()
    for presion in presiones_db:
        p=Presion(presion[0],presion[1],presion[2])
        presiones.append(p)
        mydb.commit()
    return presiones

@app.get("/distancia")
async def root():
    distancias=[]
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM distancia")
    distancias_db = mycursor.fetchall()
    mydb.commit()
    for distancia in distancias_db:
        d=Distancia(distancia[0],distancia[1],distancia[2])
        distancias.append(d)
        mydb.commit()
    return distancias