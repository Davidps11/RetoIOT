import { useEffect, useState } from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import Box from '@mui/material/Box';
import { LineChart } from '@mui/x-charts/LineChart';
import axios from 'axios';
function Distancia() {
    const [distancias, setDistancias] = useState([]);
    const [distanciasData, setDistanciasData] = useState([]);
    const [distanciasLabels, setDistanciasLabels] = useState([]);
    function getDistancias() {
      axios.get('http://localhost:8000/distancia').then((response) => {
        console.log(response.data);
        setDistancias(response.data);
        
      })
    }
  
    useEffect(() => {
      getDistancias();
    }, [])
  
    useEffect(() => {
      if(distancias.length === 0) return;
      setDistanciasData(distancias.map((distancia) => distancia.distancia));
      setDistanciasLabels(distancias.map((distancia) => distancia.fecha));
    }, [distancias])
  
    return (
        <div className='App' >
          <p className='titulo-pagina'>Sensores de distancia</p>
          <Box sx={{ flexGrow: 1, display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
            <Grid container spacing={0}>
              <Grid xs={12} md={12}>
              {distanciasLabels.length > 0 && (
                <LineChart
                  width={1000}
                  height={600}
                  series={[
                    { 
                      data: distanciasData, 
                      label: 'Distancias',
                      color: '#BC21F3',
                    },
                  ]}
                  xAxis={[{ scaleType: 'point', data: distanciasLabels }]}
                />
              )}
  
              </Grid>
            </Grid>
          </Box>
        </div>
  );
}

export default Distancia;
