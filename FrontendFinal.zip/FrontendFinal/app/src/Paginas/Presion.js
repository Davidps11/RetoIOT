import { useEffect, useState } from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import Box from '@mui/material/Box';
import { LineChart } from '@mui/x-charts/LineChart';
import axios from 'axios';
function Presion() {
    const [presiones, setPresiones] = useState([]);
    const [presionesData, setPresionesData] = useState([]);
    const [presionesLabels, setPresionesLabels] = useState([]);
    function getPresiones() {
      axios.get('http://localhost:8000/presion').then((response) => {
        console.log(response.data);
        setPresiones(response.data);
        
      })
    }
  
    useEffect(() => {
      getPresiones();
    }, [])
  
    useEffect(() => {
      if(presiones.length === 0) return;
      setPresionesData(presiones.map((presion) => presion.presion));
      setPresionesLabels(presiones.map((presion) => presion.fecha));
    }, [presiones])
  
    return (
        <div>
          <p className='titulo-pagina'>Sensores de Presión</p>
          <Box sx={{ flexGrow: 1, display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
            <Grid container spacing={0}>
              <Grid xs={12} md={12}>
                {presionesLabels.length>0 &&
                  <LineChart
                  width={1000}
                  height={600}
                  series={[
                    { 
                      data: presionesData, 
                      label: 'Presiones',
                      color: '#BC21F3', 
                    },
                  ]}
                    xAxis={[{ scaleType: 'point', data: presionesLabels }]}
                  />
                }
  
              </Grid>
            </Grid>
          </Box>
        </div>
    );
  }
  
  export default Presion;
  