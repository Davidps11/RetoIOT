import Grid from '@mui/material/Unstable_Grid2';
import '../App.css';
import imagenEjemplo from './sensor.png';

import { useNavigate} from 'react-router-dom';
function PaginaIncio() {
    const navigate = useNavigate();
    const handleClick = (path) => {
      navigate(path);
    };
    return (
    <div className="App">
      <p className='titulo-pagina'>Visualizacion de sensores</p>
      <Grid container spacing={0} style={{ marginLeft: '120px' }}>
        <Grid item xs={4}>
            <div>
              <p className='titulos'>Sensor Distancia</p>
            </div>
            <img src={imagenEjemplo} alt="Descripción de la imagen" className='imagen-sensor'/>
            <div>
            <button className='boton-mostrar'         style={{position: 'absolute', left: 240, top:710}} 
            onClick={() => handleClick('/Distancia')}>mostrar</button>
            </div>
        </Grid>

        <Grid item xs={4}>
            <div>
              <p className='titulos'>Sensor Presion</p>
            </div>

            <div>
            <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="200" height="200" viewBox="0 0 1280.000000 1280.000000" preserveAspectRatio="xMidYMid meet" style={{ position: 'absolute', left: 660,top:300 }}>
              <g transform="translate(0.000000,1280.000000) scale(0.100000,-0.100000)" fill="#000000" stroke="none">
              <path d="M6095 12794 c-27 -2 -115 -8 -195 -14 -1870 -137 -3611 -1123 -4715 -2671 -1505 -2110 -1582 -4947 -193 -7132 824 -1296 2092 -2261 3548 -2701 926 -279 1884 -347 2840 -200 761 117 1520 381 2180 759 1230 704 2185 1777 2734 3070 866 2040 607 4403 -679 6204 -886 1241 -2181 2128 -3645 2496 -340 86 -633 135 -1005 171 -150 14 -756 27 -870 18z m547 -984 c776 -36 1477 -217 2158 -556 560 -279 978 -580 1426 -1028 435 -435 743 -858 1008 -1386 325 -645 500 -1269 567 -2020 26 -288 14 -767 -27 -1095 -128 -1030 -548 -1992 -1224 -2805 -133 -160 -427 -458 -591 -601 -792 -688 -1757 -1133 -2774 -1278 -283 -41 -469 -53 -785 -53 -880 0 -1667 187 -2450 582 -738 373 -1398 931 -1901 1605 -552 742 -909 1630 -1023 2550 -55 438 -55 912 0 1350 115 926 471 1810 1031 2560 163 219 293 368 522 596 241 240 338 325 576 504 863 649 1910 1026 2980 1075 238 10 281 10 507 0z"/>
              <path d="M6240 10996 l0 -214 -77 -6 c-431 -34 -740 -89 -1062 -191 -611 -193 -1123 -482 -1608 -908 l-130 -114 -155 148 -156 149 -110 -119 -111 -118 151 -151 152 -150 -75 -89 c-664 -778 -1037 -1786 -1039 -2805 l0 -167 -52 -5 c-29 -3 -125 -11 -213 -17 -88 -6 -161 -11 -162 -12 -4 -5 21 -313 26 -319 3 -4 96 0 205 8 110 8 205 13 213 10 7 -3 13 -20 13 -40 0 -63 60 -392 101 -552 80 -317 220 -686 361 -954 156 -298 322 -544 561 -831 82 -100 146 -184 140 -188 -25 -17 -313 -262 -313 -267 0 -11 204 -244 211 -242 4 2 169 138 365 303 197 165 364 305 372 310 11 9 -37 71 -233 305 -135 162 -281 344 -324 405 -372 523 -598 1102 -688 1765 -22 168 -26 712 -5 880 108 876 465 1631 1062 2244 627 643 1406 1026 2320 1138 66 8 223 13 420 13 197 0 354 -5 420 -13 755 -93 1397 -361 1980 -826 150 -120 433 -400 553 -547 423 -520 699 -1118 811 -1759 45 -260 51 -338 51 -680 -1 -280 -4 -347 -23 -481 -66 -466 -197 -882 -403 -1278 -151 -288 -279 -471 -609 -866 -192 -230 -239 -291 -228 -300 8 -5 175 -145 372 -310 196 -165 361 -301 365 -303 7 -2 211 231 211 242 0 5 -288 251 -314 268 -5 3 44 71 110 150 203 244 309 388 426 578 245 399 417 806 529 1253 42 166 99 481 99 543 0 20 6 37 13 40 8 3 103 -2 213 -10 109 -8 202 -12 205 -8 5 6 30 314 26 319 -1 1 -74 6 -162 12 -88 6 -183 14 -211 17 l-51 5 -6 247 c-11 459 -76 838 -217 1262 -183 555 -439 1011 -824 1468 l-70 84 152 150 151 151 -111 118 -110 119 -156 -149 -155 -148 -130 114 c-484 426 -997 715 -1608 908 -322 102 -631 157 -1061 191 l-78 6 0 214 0 214 -160 0 -160 0 0 -214z"/>
              <path d="M8385 8348 c-165 -138 -605 -505 -978 -816 l-679 -565 -56 27 c-31 15 -82 33 -112 41 -74 20 -246 19 -323 -1 -229 -59 -412 -243 -471 -472 -21 -80 -22 -229 -1 -317 8 -38 12 -71 7 -74 -5 -3 -151 -125 -326 -270 l-317 -264 98 -101 c54 -56 156 -161 226 -233 70 -73 130 -133 132 -133 2 0 131 140 286 311 198 218 287 309 298 305 118 -37 270 -48 371 -26 193 43 359 175 445 355 52 107 65 166 65 285 0 103 -13 173 -47 249 l-23 54 23 26 c121 131 1675 1850 1681 1859 4 7 6 12 4 11 -2 0 -138 -113 -303 -251z"/>
              </g>
              </svg>
              <button className='boton-mostrar' style={{position: 'absolute',left: 720,top:710}} 
              onClick={() => handleClick('/Presion')}>mostrar</button>
            </div>
        </Grid>
        
        <Grid item xs={4}>
            <div>
            <p className='titulos'>Sensor Temperatura</p>
            </div>
              <svg  xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-temperature" width="400" height="400" viewBox="0 0 24 24" stroke-width="1.5" stroke="#000000" fill="none" stroke-linecap="round" stroke-linejoin="round" style={{ position: 'absolute', left: 1050 }}>
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <path d="M10 13.5a4 4 0 1 0 4 0v-8.5a2 2 0 0 0 -4 0v8.5" />
                <path d="M10 9l4 0" />
              </svg>
            <div>
            <button className='boton-mostrar' style={{position: 'absolute',left:1220,top:710}} 
            onClick={() => handleClick('/Temperatura')}>mostrar</button>
            </div>
        </Grid>
        </Grid>
    </div>
  );
}

export default PaginaIncio;
